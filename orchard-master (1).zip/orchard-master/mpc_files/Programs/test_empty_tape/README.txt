Tests a corner case of empty threads doing nothing

