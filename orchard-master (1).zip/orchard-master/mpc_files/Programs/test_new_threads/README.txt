Tests spawning and joining threads

