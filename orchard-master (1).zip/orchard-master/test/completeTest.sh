# One run simulating all committee parties on one machine

#$1 - number of parties
#$2 - program name

./test0.sh $1 $1 1
./testd.sh $1 $2
