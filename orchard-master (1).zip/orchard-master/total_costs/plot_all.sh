#!/bin/bash
gnuplot figures/*.plot
